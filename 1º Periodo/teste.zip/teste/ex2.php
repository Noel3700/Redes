<?php
$diadasemana = 7;
switch ($diadasemana) {
	case '1':
		echo "Domingo";
		break;

	case '2':
		echo "segunda feira";
		break;

		case '3':
		echo "terca feira";
		break;

		case '4':
		echo "quarta feira";
		break;

		case '5':
		echo "quinta feira";
		break;

		case '6':
		echo "sexta feira";
		break;

		case '7':
		echo "sabado";
		break;

	default:
		echo "Não existe este dia da semana";
		break;
}
?>