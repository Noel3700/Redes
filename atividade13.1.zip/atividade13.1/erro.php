<?php
echo "ERRO!<br>";
echo "Introduziu o <b>Login</B> ou a  <B>Password</B> errados.<br>";
?>