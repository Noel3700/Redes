<h6>
	<?php
	echo 'Aqui fica o rodapé.';
	?>
</h6>