<h1>
	<?php
	echo 'Aqui fica o cabeçalho do site.';
	?>
</h1>
