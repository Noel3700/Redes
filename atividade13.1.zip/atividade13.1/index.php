<!DOCTYPE html>
<header>
	<title>RC</title>
</header>
<html>
<body>
	<?php
	include('header.php');
	?>
	<br> Aqui fica o restante conteudo da pagina.<br>
	Vamos lá fazer uma soma, só de exemplo,
	<?php
	echo 3+5;
	?>
	<br>
	<?php
	include('footer.php');
	?>
	<?php
	include('login.php');
	?>
</body>
</html>