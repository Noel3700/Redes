<?php
include("header.php");
echo "Aqui ficará a parte do <B>conteúdo</B> (Esta será a parte variável do nosso site)<br>";
include("footer.php");
?>